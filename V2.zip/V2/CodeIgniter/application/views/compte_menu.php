<?php
if($this->session->has_userdata('username')==false || $this->session->has_userdata('statut')==false){ 
  redirect(base_url()."index.php/compte/deconnecter");
}
?> 
<h2>Espace d'administration</h2>
<br />
<h2>Session ouverte ! Bienvenue
<?php
	echo $this->session->userdata('username');
?> !
</h2>