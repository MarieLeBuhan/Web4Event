<?php
		if($message) echo($message);
?>
<br>
<a href="<?php echo base_url();?>index.php/programmation/afficher_admin">Retour aux gestions des programmations</a>