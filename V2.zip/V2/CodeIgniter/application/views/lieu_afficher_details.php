<div class="section-title" data-aos="fade-right">
<h2><?php echo $titre;?></h2>
<?php
	if($lieu!=NULL){
		foreach ($lieu as $l) {
			if(!isset($traite2[$l["lieu_id"]])){
				echo'<h1>'.$l["lieu_nom"].'</h1><br>'.$l["lieu_description"].'<br><ul>';
				foreach ($lieu as $li) {
					if (!isset($traite[$li["serv_id"]])){
						echo'<li type="square">'.$li["serv_nom"].'</li>';
					}
					$traite[$li["serv_id"]]=1;
				}	
			}
			$traite2[$l["lieu_id"]]=1;
		}
	}else{
		echo "Aucun lieu";
	}	
?>
</ul>
</div>