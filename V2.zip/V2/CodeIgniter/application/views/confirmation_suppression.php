Êtes-vous sûr de vouloir supprimer cette animation?

<a href="<?php echo base_url();?>index.php/programmation/supprimer/<?php echo($anim_id);?>"><bouton class="btn btn-theme">OUI</bouton></a>
<a href="<?php echo base_url();?>index.php/programmation/afficher_admin"><bouton class="btn btn-theme04">NON</bouton></a>