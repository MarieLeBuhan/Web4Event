<?php
if($this->session->has_userdata('username')==false || $this->session->has_userdata('statut')==false || strcmp($this->session->userdata('statut'),'I')==1){ 
  redirect(base_url()."index.php/compte/deconnecter");
}
?> 
<h1><?php echo $titre; ?></h1>
<?php
	if($pass!=NULL){
		echo"<table class='table table-sm'><tr><th>Identifiant pass</th><th>Mot de passe </th><th><center>Posts</center></th></tr>";
		foreach ($pass as $p) {
			if(!isset($traite[$p["pass_id"]])){
				$pass_id=$p["pass_id"];
				echo"<tr><td>".$p["pass_id"]."</td><td>".$p["pass_mdp"]."</td><td>";
				if($p["post_id"]!=NULL){
					foreach($pass as $pa){
					echo"<ul>";
					if(strcmp($pass_id,$pa["pass_id"])==0){
						echo'<li>- '.$pa["post_message"].' -- '.$pa["post_date"].' --';
						if(strcmp($pa["post_etat"],'P')==0){
							echo" Publié";
						}else{
							echo" Brouillon";
						}
						echo"</li>";			
					}
					echo"</ul>";
					}
				}else{
					echo"<i>Pas de posts!</i>";
				}
				echo"</td></tr>";
				$traite[$p["pass_id"]]=1;
			}
		}
		echo"</table>";

	}else{
		echo"Aucun passeport!";
	}
?>

