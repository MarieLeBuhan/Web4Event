        </div>
      </div>
    </section>
  </main>
 <!-- ======= Footer =======-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Stade Roland-Garros</h3>
            <p>2 avenue Gordon Bennett<br>75016 Paris<br>France<br>
              <strong>Téléphone:</strong> 01.47.43.48.00<br>
              <strong>Email:</strong> accueil@fft.fr<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Partenaires</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">BNP Paribas</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Emirates</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Lacoste</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Rolex</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Oppo</a></li>
            </ul>
          </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>Bethany</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
      </div>
      <div class="social-links text-center text-md-right pt-3 pt-md-0">
        <a href="https://www.facebook.com/RolandGarros" class="facebook"><i class="bx bxl-facebook"></i></a>
        <a href="https://twitter.com/rolandgarros" class="twitter"><i class="bx bxl-twitter"></i></a>
        <a href="https://www.instagram.com/rolandgarros/" class="instagram"><i class="bx bxl-instagram"></i></a>
        <a href="https://www.youtube.com/c/RolandGarros" class="youtube"><i class="bx bxl-youtube"></i></a>
        <!--<a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>-->
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?php echo base_url();?>style/assets/vendor/aos/aos.js"></script>
  <script src="<?php echo base_url();?>style/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url();?>style/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?php echo base_url();?>style/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?php echo base_url();?>style/assets/vendor/php-email-form/validate.js"></script>
  <script src="<?php echo base_url();?>style/assets/vendor/purecounter/purecounter.js"></script>
  <script src="<?php echo base_url();?>style/assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="<?php echo base_url();?>style/assets/js/main.js"></script>

</body>

</html>