<div class="section-title" data-aos="fade-right">
<h2><?php echo $titre;?></h2>
<div class="row portfolio-container" data-aos="fade-up" ata-aos-delay="200">
<?php 
  if($inv!=NULL) {
    foreach($inv as $i){
    	if (!isset($traite[$i["inv_id"]])){
        	$INV_id=$i["inv_id"];
        	echo'<div class="col-lg-4 col-md-6 portfolio-item filter-app">
              	<div class="portfolio-wrap">
                <img src="'.base_url().'style/documents/'.$i["inv_photo"].'" class="img-fluid" width="500" height="500" alt="">
                <div class="portfolio-info">
                <section id="team" class="team"><div class="member">
                <div class="member-info">
                <h4>'.$i["inv_nom"].'</h4><span></span><p>';
                	if($i["post_id"]!=NULL){
                    	foreach ($inv as $invite) {
	                        if(strcmp($INV_id,$invite["inv_id"])==0 ){
	                        	if(!isset($traite3[$invite["post_message"]])){
		                        	if($invite["post_message"]!=NULL){
		                            	echo $invite["post_message"];
		                            	echo"</br>";
		                        	}
									$traite3[$invite["post_message"]]=1;	                   
		                        }	
	                        }   
	                    }
                	}else{echo"<i>Pas de post pour cet invité !</i><br>";}
                	echo"<span></span>";
                  	if($i["rs_id"]!=NULL){         
                    	echo' <div class="social">';
                    	foreach ($inv as $rs) {
                      if(strcmp($INV_id,$rs["inv_id"])==0){
                        if(!isset($traite2[$rs["rs_url"]])){        
                          if(strcmp($rs["rs_nom"],"Twitter")==0){
                            echo'<a href="'.$rs["rs_url"].'"><i class="bx bxl-twitter"></i></a>';
                          }else if(strcmp($rs["rs_nom"],"Instagram")==0){
                            echo'<a  href="'.$rs["rs_url"].'"> <i class="ri-instagram-fill"></i></a>';} 
                          else if(strcmp($rs["rs_nom"],"Facebook")==0){
                            echo'<a href="'.$rs["rs_url"].'"><i class="bx bxl-facebook"></i></a>';}
                          else{
                            echo '<a href="'.$rs["rs_url"].'">'.$rs["rs_nom"].'</a></br>';
                          }    
                          $traite2[$rs["rs_url"]]=1;
                        }
                      }
                    }  
                    echo'</div>';
                  }else{echo"<p>Pas de réseau social pour cet invité !</p>";}
                echo'</div></div>';
				        echo'<a href="'.base_url().'style/documents/'.$i["inv_photo"].'" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Plus de détails"><i class="bx bx-plus"></i></a>';
                echo'</section>';
                echo'</p> <div class="portfolio-links"></div></div></div></div>';  
       			$traite[$i["inv_id"]]=1;
      		}
    	}   
 	}else{
    	echo "Aucun invité!";
  	}            
?>
</div>  



</div>