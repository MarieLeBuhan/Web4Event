<div class="section-title" data-aos="fade-right">
  <h2><?php echo $titre ?></h2>

<?php 
if($message){
	echo($message); echo'<br>';
}
?>

<?php echo validation_errors(); ?>
<?php echo form_open('invite/ajout_post'); ?>

<label>Passeport:</label><br>
 <input type="text" name="pass_id" />
<input type="password" name="pass_mdp" /><br>
<label>Post:</label>
<textarea class="form-control" rows=5 maxlength="140" name="post_texte" /></textarea><br>
<input type="submit" value="Publier"/>
</form>





</div>