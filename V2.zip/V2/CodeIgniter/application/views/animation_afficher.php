<div class="section-title" data-aos="fade-right">
<?php
echo'<h2>'.$titre.'</h2>';
echo'<p><h1>'.$infos->anim_titre.'</h1><br>Débutera le '.$infos->anim_date_debut.' et se terminera le '.$infos->anim_date_fin.'.</p>';



?>
</div>