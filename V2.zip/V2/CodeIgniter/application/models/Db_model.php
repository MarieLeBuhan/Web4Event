<?php
	class Db_model extends CI_Model {
		//constructeurs
		 public function __construct(){
		 	$this->load->database();
		 }
		 
		//récupérer tous les pseudos
		 public function get_all_compte(){
			$query = $this->db->query("SELECT cpt_pseudo FROM t_compte_cpt;");
			return $query->result_array();
		}

		//récupérer une actualité précise
		public function get_actualite($numero){
			$query = $this->db->query("SELECT * FROM t_actualite_actu WHERE actu_id=".$numero.";");
			return $query->row();
		}

		//récupérer les 5 dernières actualités publiées
		public function get_all_actualite(){
			$query = $this->db->query("SELECT * FROM t_actualite_actu JOIN t_organisateur_orga USING(orga_id) WHERE actu_etat='P' ORDER BY actu_date_publication DESC LIMIT 5;");
			return $query->result_array();
		}
		
		//récupère toutes les données des animations
		public function get_programmation(){
			$query = $this->db->query("SELECT *, EtatAnim(anim_id) as etat FROM t_animation_anim LEFT JOIN t_lieu_lieu USING (lieu_id) LEFT JOIN tj_programmation_prog USING(anim_id) LEFT JOIN t_invite_inv USING (inv_id) ORDER BY anim_date_debut;");
			return $query->result_array();
		}

		//récupère toutes les données sur les RéSEAUX SOCIAUX et les POSTS liés aux invités
		public function get_invite(){
			$query = $this->db->query("SELECT * FROM t_invite_inv LEFT JOIN tj_inv_rs USING(inv_id) LEFT JOIN t_reseaux_sociaux_rs USING(rs_id)LEFT JOIN t_passeport_pass USING(inv_id) LEFT JOIN t_post_post USING (pass_id) ORDER BY post_date DESC;");
			return $query->result_array();
		}

		//création d'un compte
		public function set_compte(){
			$this->load->helper('url');
			$id=htmlspecialchars(addslashes($this->input->post('id')));
			$mdp=htmlspecialchars(addslashes($this->input->post('mdp')));
			$etat=htmlspecialchars(addslashes($this->input->post('etat')));
			$req="INSERT INTO t_compte_cpt VALUES ('".$id."','".$mdp."','".$etat."');";
			$query = $this->db->query($req);
			return ($query);
		}

		//se connecter à partir de son pseudo, un mdp 
		public function connect_compte($username, $password){
			$query =$this->db->query("SELECT cpt_pseudo,cpt_mdp FROM t_compte_cpt WHERE cpt_pseudo='".$username."' AND cpt_mdp='".$password."';");
			if($query->num_rows() > 0){ 
				return true; 
			}else{ 
				return false;
			} 
		}

		//on récupère le statut à partir du pseudo de la personne connectée
		public function get_statut($username){
			$query =$this->db->query("SELECT cpt_etat FROM t_compte_cpt	WHERE cpt_pseudo='".$username."';");
			return $query->row();
		}

		//on récupère les infos du profil
		public function infos_pfl($username){
			$query =$this->db->query("SELECT * FROM DonneesProfils  LEFT JOIN tj_inv_rs USING(inv_id) LEFT JOIN t_reseaux_sociaux_rs USING(rs_id) WHERE cpt_pseudo='".$username."';");
			return $query->row();
		}

		//on récupère les informations sur les lieux et les informations sur leurs services associés
		public function get_lieu(){
			$query = $this->db->query("SELECT * FROM lieuserv;");
			return $query->result_array();
		}

		//modification du mot de passe
		public function modif_mdp($id,$mdp){
			$req="UPDATE t_compte_cpt SET cpt_mdp='".$mdp."' WHERE cpt_pseudo='".$id."';";
			$query = $this->db->query($req);
			return ($query);
		}
		//récupère les information concernant une animation
		public function infos_anim($anim_id){
			$query =$this->db->query("SELECT * FROM t_animation_anim WHERE anim_id='".$anim_id."';");
			return $query->row();
		}

		//récupère les informations d'un lieu précis ainsi que les services qui y sont associés
		public function infos_lieu($lieu){
			$query =$this->db->query("SELECT * FROM lieuserv WHERE lieu_id='".$lieu."';");
			return $query->result_array();
		}
		//récupère toutes les données sur les RéSEAUX SOCIAUX et les POSTS liés aux invités
		public function infos_invite_anim($anim){
			$query = $this->db->query("SELECT * FROM t_animation_anim LEFT JOIN tj_programmation_prog USING(anim_id) LEFT JOIN t_invite_inv USING(inv_id) LEFT JOIN tj_inv_rs USING(inv_id) LEFT JOIN t_reseaux_sociaux_rs USING(rs_id) LEFT JOIN t_passeport_pass USING(inv_id) LEFT JOIN t_post_post USING (pass_id) WHERE anim_id='".$anim."' ORDER BY post_date DESC;");
			return $query->result_array();
		}

		//se connecter à un passeport partir de son pseudo, un mdp 
		public function connect_pass($username, $password){
			$query =$this->db->query("SELECT pass_id, pass_mdp FROM t_passeport_pass WHERE pass_id='".$username."' AND pass_mdp='".$password."';");
			if($query->num_rows() > 0){ 
				return true; 
			}else{ 
				return false;
			} 
		}

		//insérer un nouveau post
		public function ajout_post(){
			$this->load->helper('url');
			$id=htmlspecialchars(addslashes($this->input->post('pass_id')));
			$mdp=htmlspecialchars(addslashes($this->input->post('pass_mdp')));
			$post_texte=htmlspecialchars(addslashes($this->input->post('post_texte')));
			$req="INSERT INTO t_post_post VALUES (NULL,'".$post_texte."',NOW(), 'P','".$id."');";
			$query = $this->db->query($req);
			return ($query);
		}

		//récupération de TOUS les pass et des posts associé d'un invité précis
		public function infos_pass($pseudo){
			$query = $this->db->query("SELECT * FROM t_passeport_pass LEFT JOIN t_post_post USING(pass_id) LEFT JOIN t_invite_inv USING(inv_id) LEFT JOIN t_compte_cpt USING(cpt_pseudo) WHERE cpt_pseudo='".$pseudo."';");
			return $query->result_array();
		}

		public function Supp($anim){
			$req="CALL SuppAnim('".$anim."')";
			$query = $this->db->query($req);
			return ($query);
		}
		
	}
?>