<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Invite extends CI_Controller {
 
	 public function __construct(){
		 parent::__construct();
		 $this->load->model('db_model');
		 $this->load->helper('url_helper');
	 }

	public function afficher(){
		$data['titre'] = 'Invités';
		$data['inv'] = $this->db_model->get_invite();

		$this->load->view('templates/haut');
		$this->load->view('invite_affichage_galerie',$data);
		$this->load->view('templates/bas');
	 }

	public function afficher_par_anim($anim){
		$data['titre'] = 'Invités';
		$data['inv'] = $this->db_model->infos_invite_anim($anim);

		$this->load->view('templates/haut');
		$this->load->view('invite_galerie_par_anim',$data);
		$this->load->view('templates/bas');
	 }
	 public function ajout_post(){
	 	$this->load->helper('form');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('pass_id', 'pass_id', 'required', array('required'=>'Veuillez rentrer votre identifiant.'));
		$this->form_validation->set_rules('pass_mdp', 'pass_mdp', 'required', array('required'=>'Veuillez rentrer votre mot de passe.'));
		$this->form_validation->set_rules('post_texte','post_texte', 'required|max_length[140]', array('required'=>'Post vide','max_length[140]'=>'Un post a 140 caractères maximum.'));//


		$data['titre'] = 'Formulaire d\'ajout de posts';
		$data['message']=NULL;
		if ($this->form_validation->run() == FALSE){
			$this->load->view('templates/haut');
			$this->load->view('formulaire_post',$data);
			$this->load->view('templates/bas');
		}else{
			$passid=htmlspecialchars(addslashes($this->input->post('pass_id')));
			$passmdp=htmlspecialchars(addslashes($this->input->post('pass_mdp')));
			if($this->db_model->connect_pass($passid,$passmdp)){
				$post=htmlspecialchars(addslashes($this->input->post('post_texte')));
				if($this->db_model->ajout_post()){
					$data['message']='Post publié!';
					$this->load->view('templates/haut');
					$this->load->view('formulaire_post',$data);
					$this->load->view('templates/bas');
				}else{
					$data['message']='Erreur d\'insertion du post!';
					$this->load->view('templates/haut');
					$this->load->view('formulaire_post',$data);
					$this->load->view('templates/bas');
				}
			}else{
				$data['message']='Code(s) erroné(s), aucun passeport trouvé !';
				$this->load->view('templates/haut');
				$this->load->view('formulaire_post',$data);
				$this->load->view('templates/bas');
			}
		}


	 }

}
?>