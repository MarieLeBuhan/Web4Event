<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Animation extends CI_Controller {
 
	 public function __construct(){
		 parent::__construct();
		 $this->load->model('db_model');
		 $this->load->helper('url_helper');
	 }

	public function afficher($anim){
		//if(isset)
		//$data['anim']=$this->input->get('anim_id', TRUE);
		$data['titre'] = 'animation';
		$data['infos']=$this->db_model->infos_anim($anim);
		$data['anim']=$anim;
		$this->load->view('templates/haut');
		$this->load->view('animation_afficher',$data);
		$this->load->view('templates/bas');
	}


}
?>