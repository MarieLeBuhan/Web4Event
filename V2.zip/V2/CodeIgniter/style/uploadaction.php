<?php
	$mysqli = new mysqli('localhost','zle_buhma','1kbrz99g','zal3-zle_buhma');
	$uploaddir= __DIR__. '/documents/';
	$uploadfile=$uploaddir.basename($_FILES['userfile']['name']);
	echo $uploadfile;
	
	echo '<pre>';
	if(move_uploaded_file($_FILES['userfile']['tmp_name'],$uploadfile)){
		echo "Le fichier est valide, et a été téléchargé avec succès.Voici plus d'informations :\n";
	} else{
		echo "Le fichier n'a pas été téléchargé. Il y a eu un problème! \n";
	}
	echo 'Voici quelques informations sur le téléversement:';
	print_r($_FILES);

	
	$req="UPDATE t_invite_inv set inv_photo='". $_FILES['userfile']['name'] ."' where inv_id='4';"; 
	//_". date("d.m.y_H:i:s")." 
	//renommer dès upload.php pour que ce soit le bon nom dans gabarit/documents/
	echo $req;
	$rslt=$mysqli->query($req);
	if($rslt==NULL){
		echo"\nErreur";
		
	}else{
		//Si le changement s'est produit, on l'affiche
		echo "reussi";
		echo "<a href='http://obiwan2.univ-brest.fr/licence/lic73/gabarit/index.php'>Index</a>";

	}


	$mysqli->close();
?>

