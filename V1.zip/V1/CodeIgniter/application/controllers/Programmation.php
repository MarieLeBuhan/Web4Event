<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Programmation extends CI_Controller {
 
	 public function __construct(){
		 parent::__construct();
		 $this->load->model('db_model');
		 $this->load->helper('url_helper');
	 }

	public function afficher(){
		$data['titre'] = 'Programmation';
		$data['prog'] = $this->db_model->get_programmation();
			 
		$this->load->view('templates/haut');
		$this->load->view('programmation_afficher',$data);
		$this->load->view('templates/bas');
	 }


	public function afficher_admin(){
		$data['titre'] = 'Programmation';
		$data['prog'] = $this->db_model->get_programmation();
			 
		$this->load->view('templates/haut_admin');
		if(strcmp($this->session->userdata('statut'),'I')==0){
			$this->load->view('menu_invite');
		}
		if(strcmp($this->session->userdata('statut'),'O')==0){
			$this->load->view('menu_administrateur');
		}
		$this->load->view('programmation_afficher_admin',$data);
		$this->load->view('templates/bas_admin');
	}


}
?>