<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Profil extends CI_Controller {
 
	 public function __construct(){
		 parent::__construct();
		 $this->load->model('db_model');
		 $this->load->helper('url_helper');
	 }

	 public function afficher(){
	 	$pseudo = $this->session->userdata('username');
	 	$data['titre'] = 'Modification profil:'; // s?
		$data['infos'] = $this->db_model->infos_pfl($pseudo);
		$data['message']=NULL;

		$this->load->helper('form');
		$this->load->library('form_validation');
		
		$this->form_validation->set_rules('mdp', 'mdp', 'required', array('required'=>'Champ du mot de passe vide!'));
		$this->form_validation->set_rules('mdp_conf', 'mdp_conf', 'required', array('required'=>'Champ de la confirmation du mot de passe vide!'));

		if ($this->form_validation->run() == FALSE){
			$this->load->view('templates/haut_admin');
			if(strcmp($this->session->userdata('statut'),'I')==0){
				$this->load->view('menu_invite');
			}
			if(strcmp($this->session->userdata('statut'),'O')==0){
				$this->load->view('menu_administrateur');
			}
			$this->load->view('profil_invite',$data);
			$this->load->view('templates/bas_admin');
		}else{
			$mdp = $this->input->post('mdp'); 
			$mdp_conf = $this->input->post('mdp_conf');
			if(strcmp($mdp,$mdp_conf)==0){
				$salt = "OnRajouteDuSelPourAllongerleMDP123!!45678__Test";
				$password = hash('sha256', $salt.$mdp);
				if($this->db_model->modif_mdp($pseudo, $password)){
					$data['message']='Mot de passe modifié!';
					$this->load->view('templates/haut_admin');
					if(strcmp($this->session->userdata('statut'),'I')==0){
						$this->load->view('menu_invite');
					}
					if(strcmp($this->session->userdata('statut'),'O')==0){
						$this->load->view('menu_administrateur');
					}
					$this->load->view('profil_invite',$data);
					$this->load->view('templates/bas_admin');
				}else{
					$data['message']='Erreur d\'insertion!';
					$this->load->view('templates/haut_admin');
					if(strcmp($this->session->userdata('statut'),'I')==0){
						$this->load->view('menu_invite');
					}
					if(strcmp($this->session->userdata('statut'),'O')==0){
						$this->load->view('menu_administrateur');
					}
					$this->load->view('profil_invite',$data);
					$this->load->view('templates/bas_admin');
				}				
			}else{
				$data['message']='Confirmation du mot de passe erronée, veuillez réessayer !';
				$this->load->view('templates/haut_admin');
				if(strcmp($this->session->userdata('statut'),'I')==0){
				$this->load->view('menu_invite');
				}
				if(strcmp($this->session->userdata('statut'),'O')==0){
					$this->load->view('menu_administrateur');
				}
				$this->load->view('profil_invite',$data);
				$this->load->view('templates/bas_admin');
			}		
		}
	 }	 
}
?>