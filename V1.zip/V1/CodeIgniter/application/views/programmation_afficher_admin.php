<?php
if($this->session->has_userdata('username')==false || $this->session->has_userdata('statut')==false || strcmp($this->session->userdata('statut'),'O')!=0){ 
  redirect(base_url()."index.php/compte/deconnecter");
}
?> 
<h1><?php echo $titre;?></h1>
<br />
<?php 
	$e=-1;
	echo'<a href="" title="Ajouter"><i class="fa fa-plus"></i></a>';
	if($prog!=NULL) {
		foreach ($prog as $pg) {
			if($e<2){ 
				$e=$e+1;
				if($e==0){$etat="Animations passées";}
				else if($e==1){$etat="Animations en cours";}
				else if ($e==2){$etat="Animations à venir";}
				echo '<h2>'.$etat.'</h2>';
				echo "<table class='table table-hover'><thead><tr>
					<th>Animation</th>
					<th>Animation début</th>
					<th>Animation fin</th>
					<th>Lieu</th>
					<th>Invitées</th><th></th><th></th>
					</tr><thead><tbody>";
				foreach ($prog as $programmation) {
					if (!isset($traite[$programmation["anim_id"]]) && $programmation["etat"]==$e){
						$ANIM_id=$programmation["anim_id"];
						echo"<tr><td>";
						echo $programmation["anim_titre"];
						echo'<br>';
						echo"</td><td>";
						echo $programmation["anim_date_debut"];
						echo"</td><td>";
						echo $programmation["anim_date_fin"];
						echo"</td>";
						if($programmation["lieu_id"]!=NULL){
							echo"<td>";
							echo $programmation["lieu_nom"];
							echo'<br>';
							echo"</td>";
						}else{
							echo"<td>Aucun lieu pour le moment</td>";
						}
						echo"<td>";
						if($programmation["inv_id"]==NULL){
								echo"Aucun invité pour le moment";
						}else{
							foreach($prog as $p){
								echo "<ul>";
								if(strcmp($ANIM_id,$p["anim_id"])==0){
									echo "<li>";
									echo $p["inv_nom"];
									echo"--";
									echo$p["inv_discipline"];
									echo "</li>";
								}

								echo "</ul>";
							}
						}
						echo"</td>";
						echo'<td><a href="" title="Modifier"><i class="fa fa-pencil"></i></a></td>';
						echo'<td><a href="" title="Supprimer"><i class="fa fa-times"></i></a></td>';
						$traite[$programmation["anim_id"]]=1;
						echo"</tr>";
					}
				}
				echo"</tbody> </table>";
			}
		}
	}
	else {
		echo "<br />";
		echo "Aucune animation pour l'instant !";
	}
?>
</div>