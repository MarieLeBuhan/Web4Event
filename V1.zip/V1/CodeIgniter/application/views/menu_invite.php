<?php
if($this->session->has_userdata('username')==false || $this->session->has_userdata('statut')==false || strcmp($this->session->userdata('statut'),'I')==1){ 
  redirect(base_url()."index.php/compte/deconnecter");
}
?> 
<aside>
  <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><!--<a href="profile.html">-->
          <img src="<?php echo base_url();?>style/documents/<?php echo $this->session->userdata('username');?>.png" class="img-circle" width="80"></a></p> 
          <h5 class="centered"><?php echo $this->session->userdata('username');?></h5><!--$this->session->userdata('username')-->
          <li class="mt">
            <a class="" href="<?php echo base_url();?>index.php/compte/affich_admin_accueil"><!-- active-->
              <i class="fa fa-dashboard"></i>
              <span>Accueil invité</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="<?php echo base_url();?>index.php/profil/afficher">
              <i class="fa fa-desktop"></i>
              <span>Profil</span>
              </a>
        </ul>
      </div>
    </aside>
    <!--sidebar end-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-9 main-chart">