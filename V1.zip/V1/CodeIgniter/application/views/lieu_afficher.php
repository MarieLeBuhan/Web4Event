<div class="section-title" data-aos="fade-right">
<h2><?php echo $titre;?></h2><br>
<?php
	if($lieu!=NULL){
		echo"<table class='table'><tr><th>Lieu</th><th>Description</th><th>Services</th></tr>";
		foreach ($lieu as $l) {
			if(!isset($traite[$l["lieu_id"]])){
				$lieu_id=$l["lieu_id"];
				echo"<tr><td>".$l["lieu_nom"]."</td><td>".$l["lieu_description"]."</td><td>";
				if($l["serv_id"]!=NULL){
					foreach($lieu as $li){
					echo"<ul>";
					if(strcmp($lieu_id,$li["lieu_id"])==0){
						echo"<li>".$li["serv_nom"];
						if($li["serv_description"]!=NULL){
							echo" -- ".$li["serv_description"]."</li>";
						}			
					}
					echo"</ul>";
					}
				}else{
					echo"<i>Pas de service dans ce lieu !</i>";
				}
				echo"</td></tr>";
				$traite[$l["lieu_id"]]=1;
			}
		}
		echo"</table>";

	}else{
		echo"Aucun lieu pour l'instant!";
	}
?>
</div>