<?php
if($this->session->has_userdata('username')==false || $this->session->has_userdata('statut')==false){ 
  redirect(base_url()."index.php/compte/deconnecter");
}
?> 
<h2><?php echo $titre." ".$this->session->userdata('username'); ?></h2>
<p>
<?php
	if(strcmp($this->session->userdata('statut'),'I')==0){
		echo "<b>".$infos->inv_nom."</b><br>".$infos->inv_discipline."<br>".$infos->inv_biographie."<br>".$infos->rs_url."<br>";
	}
	if(strcmp($this->session->userdata('statut'),'O')==0){
		echo "<b>".$infos->nom_orga." ".$infos->nom_orga."</b><br>".$infos->orga_mail."<br>";
	}	
?>
<?php if($message){
	echo($message); echo'<br>';
}
?>
<?php echo validation_errors(); ?>
<?php echo form_open('profil/afficher'); ?>
	
</p>
<form>
	Mot de passe:<input type="password" name="mdp"/><br><br>
	Confirmer le mot de passe:<input type="password" name="mdp_conf"/><br><br>
	<input type="submit" class="btn btn-theme" value="Modifier"/>
 <a href="<?php echo base_url();?>index.php/profil/afficher"><button type="reset" class="btn btn-theme04">Annuler</button></a> 
</form>
<br>



