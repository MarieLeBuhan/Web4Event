
<?php echo validation_errors(); ?>
<?php echo form_open('compte/connecter'); ?>
<?php if($message){
	echo($message); echo'<br>';
}
?>
<label>Saisissez vos identifiants ici :</label><br>
<input type="text" name="pseudo" />
<input type="password" name="mdp" />
<input type="submit" value="Connexion"/>
</form>