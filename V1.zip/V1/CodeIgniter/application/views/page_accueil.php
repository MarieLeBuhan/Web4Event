<div class="section-title" data-aos="fade-right">
  <h2>Bienvenue</h2>
  <p>Le célèbre tournoi <b>Roland Garros</b> met en avant les <b>FEMMES</b>. Voici un zoom sur le tournoi des simples dames du 30 mai au 13 juin 2021 à Paris où les billets sont mis en vente chez nos partenaires officiels.</p>

</div>
<div class="section-title" data-aos="fade-right">
 <h2><?php echo $titre;?></h2>
 <?php 
  if($actu!=NULL) {
    echo "<table class='table'><tr><th>Titre</th><th>Description</th><th>Date de publication</th><th>Auteur</th></tr>";
    foreach ($actu as $act) {
      echo"<tr><td>";
      echo $act["actu_titre"];
      echo"</td><td>";
      echo $act["actu_texte"];
      echo"</td><td>";
      echo $act["actu_date_publication"];
      echo"</td><td>";
      echo $act["nom_orga"].' '.$act["prenom_orga"];
      echo"</td></tr>";     
    }
    echo"</table>";
  }
  else {echo "<br />";
  echo "Aucune actualité pour l'instant !";
  }
?>
</div>      
