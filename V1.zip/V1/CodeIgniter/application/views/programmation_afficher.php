<div class="section-title" data-aos="fade-right">
<h2><?php echo $titre;?></h2>
<br />
<?php 
	$e=-1;
	if($prog!=NULL) {
		foreach ($prog as $pg) {
			if($e<2){ 
				$e=$e+1;
				if($e==0){$etat="Animations passées";}
				else if($e==1){$etat="Animations en cours";}
				else if ($e==2){$etat="Animations à venir";}
				echo '<h1>'.$etat.'</h1>';
				echo "<table class='table table-hover'><thead><tr>
					<th>Animation</th>
					<th>Animation début</th>
					<th>Animation fin</th>
					<th>Lieu</th>
					<th>Invitées</th>
					</tr><thead><tbody>";
				foreach ($prog as $programmation) {
					if (!isset($traite[$programmation["anim_id"]]) && $programmation["etat"]==$e){
						$ANIM_id=$programmation["anim_id"];
						echo"<tr><td>";
						echo $programmation["anim_titre"];
						echo'<br><a href="" title="Plus de détails"><i class="bx bx-plus"></i></a>';
						echo"</td><td>";
						echo $programmation["anim_date_debut"];
						echo"</td><td>";
						echo $programmation["anim_date_fin"];
						echo"</td>";
						if($programmation["lieu_id"]!=NULL){
							echo"<td>";
							echo $programmation["lieu_nom"];
							echo'<br><a href="" title="Plus de détails"><i class="bx bx-plus"></i></a>';
							echo"</td>";
						}else{
							echo"<td>Aucun lieu</td>";
						}
						echo"<td>";
						if($programmation["inv_id"]==NULL){
								echo"Aucun invité";
						}else{
							foreach($prog as $p){
								echo "<ul>";
								if(strcmp($ANIM_id,$p["anim_id"])==0){
									echo "<li>";
									echo $p["inv_nom"];
									echo"--";
									echo$p["inv_discipline"];
									echo'<a href="" title="Plus de détails"><i class="bx bx-plus"></i></a>';
									echo "</li>";
								}
								echo "</ul>";
							}
						}
						echo"</td>";
						$traite[$programmation["anim_id"]]=1;
						echo"</tr>";
					}
				}
			}
			echo"</tbody> </table>";
		}
	}
	else {
		echo "<br />";
		echo "Aucune animation pour l'instant !";
	}
?>
</div>